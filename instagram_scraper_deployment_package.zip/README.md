# Instagram Handle Scraper

A powerful web scraping tool that extracts Instagram handles from company websites and exports the results to Excel spreadsheets.

## Features

- 🔍 **Intelligent Scraping**: Uses both BeautifulSoup and Selenium for comprehensive website analysis
- 📊 **Batch Processing**: Process multiple websites from CSV files
- 🎯 **Pattern Recognition**: Advanced regex patterns to find Instagram handles
- 📈 **Excel Export**: Results exported to Excel with detailed information
- 🖥️ **Interactive Mode**: Process single URLs interactively
- 🔄 **Fallback Method**: Falls back to Selenium if regular scraping fails
- 📝 **Detailed Logging**: Comprehensive logging for monitoring progress

## Installation

1. Clone or download this repository
2. Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Usage

### Method 1: Run the Main Application

```bash
python main.py
```

This will open an interactive menu with the following options:
1. Process CSV file with multiple websites
2. Interactive mode (single URLs)
3. Create sample CSV file
4. Exit

### Method 2: Direct Script Usage

```python
from instagram_scraper import InstagramScraper

# Initialize scraper
scraper = InstagramScraper(use_selenium=True, headless=True)

# Process CSV file
results = scraper.process_websites_from_csv('websites.csv', 'results.xlsx')

# Process single URL
result = scraper.process_single_url('https://example.com', 'Company Name')

# Close scraper
scraper.close()
```

## Input Format

### CSV File Structure
Your input CSV file should contain website URLs. The tool automatically detects columns with names like:
- `url`, `website`, `link`, `site` (for URLs)
- `name`, `company`, `firm` (for company names)

Example CSV:
```csv
Company_Name,Website_URL
Apple Inc.,https://www.apple.com
Microsoft Corporation,https://www.microsoft.com
Google LLC,https://www.google.com
```

## Output Format

The tool generates an Excel file with the following columns:
- **Firm_Name**: Company name
- **Website_URL**: Original website URL
- **Instagram_Handles**: Found Instagram handles (comma-separated)
- **Number_of_Handles**: Count of handles found
- **Status**: Success/No Instagram Found
- Additional columns from the original CSV are preserved

## Configuration Options

### InstagramScraper Parameters

```python
scraper = InstagramScraper(
    use_selenium=True,  # Use Selenium for JavaScript-heavy sites
    headless=True       # Run browser in headless mode
)
```

### Supported Instagram Patterns

The tool recognizes various Instagram URL formats:
- `instagram.com/username`
- `@username` mentions
- `ig.me/username`
- `instagr.am/username`

## Requirements

- Python 3.7+
- Chrome browser (for Selenium)
- Internet connection

## Dependencies

- `requests` - HTTP library
- `beautifulsoup4` - HTML parsing
- `pandas` - Data manipulation
- `openpyxl` - Excel file handling
- `selenium` - Web automation
- `webdriver-manager` - Chrome driver management
- `lxml` - XML/HTML parser

## Error Handling

The tool includes comprehensive error handling:
- Network timeouts
- Invalid URLs
- Missing files
- Selenium failures
- Rate limiting protection

## Best Practices

1. **Respectful Scraping**: The tool includes delays between requests
2. **User Agent**: Uses realistic browser user agents
3. **Fallback Methods**: Multiple scraping strategies for reliability
4. **Logging**: Detailed logs for troubleshooting

## Example Output

```
Firm_Name                | Instagram_Handles    | Status
-------------------------|---------------------|--------
Apple Inc.              | apple               | Success
Microsoft Corporation   | microsoft           | Success
Local Business          | Not Found           | No Instagram Found
```

## Troubleshooting

### Common Issues

1. **Chrome Driver Issues**: The tool automatically manages Chrome drivers
2. **Network Errors**: Check internet connection and firewall settings
3. **Permission Errors**: Run with appropriate file permissions
4. **Rate Limiting**: The tool includes built-in delays

### Logs

Check the console output for detailed logging information about the scraping process.

## Legal Notice

This tool is for educational and legitimate business purposes only. Always respect:
- Website terms of service
- Rate limits
- Privacy policies
- Copyright laws

## License

This project is for educational purposes. Use responsibly and in compliance with applicable laws and website terms of service.
